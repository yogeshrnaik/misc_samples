lgpaint is a free Java applet to make paintings.
You can draw by hand using a colored pen,
or you can use premade stamps. You can even
select a background to paint on. The program
allows you to change the stamps and backgrounds
to your own images.

Requires a Java 1.1 enabled web browser.

Unzip the contents of this zip file into the directory of your choice.

Open up readmelgp.html for instructions on the applet.

This applet is Freeware, and is freely distributable.

If there is a question or problem, contact Lawrence Goetz at:
goetz@lawrencegoetz.com

Visit my web site for other software I've made:
http://www.lawrencegoetz.com/